import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import { formatDate, formatDateTime } from "@/lib/utils/format";
import Link from "next/link";

export const metadata: Metadata = { title: "Customer" };

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: business } = await supabase
    .from("businesses").select("id").eq("owner_id", user.id).single();
  if (!business) redirect("/login");

  const { data: customer } = await supabase
    .from("customers")
    .select("*")
    .eq("id", id)
    .eq("business_id", business.id)
    .single();

  if (!customer) notFound();

  const { data: interactions } = await supabase
    .from("interactions")
    .select("id, status, sent_at, message_body, direction")
    .eq("customer_id", id)
    .order("created_at", { ascending: false });

  const { data: feedback } = await supabase
    .from("feedback_sessions")
    .select("rating, sentiment, response_text, submitted_at, status")
    .eq("customer_id", id)
    .order("created_at", { ascending: false });

  const STATUS_COLORS: Record<string, string> = {
    sent: "bg-blue-50 text-blue-600",
    delivered: "bg-blue-50 text-blue-700",
    replied: "bg-green-50 text-green-700",
    pending: "bg-gray-100 text-gray-500",
    failed: "bg-red-50 text-red-600",
  };

  const SENTIMENT_COLORS: Record<string, string> = {
    positive: "bg-green-50 text-green-700",
    neutral: "bg-gray-100 text-gray-600",
    negative: "bg-red-50 text-red-600",
  };

  return (
    <div className="p-8 max-w-3xl">
      <Link href="/customers" className="text-sm text-gray-500 hover:text-gray-700 mb-6 inline-flex items-center gap-1">
        ← Customers
      </Link>

      <div className="mb-8">
        <h1 className="text-xl font-semibold text-gray-900">{customer.name}</h1>
        <p className="text-sm text-gray-500 font-mono mt-0.5">{customer.phone}</p>
        <p className="text-xs text-gray-400 mt-1">Added {formatDate(customer.created_at)}</p>
      </div>

      {/* Interactions */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold text-gray-900 mb-3">Messages</h2>
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          {!interactions?.length ? (
            <p className="text-sm text-gray-500 p-5">No messages sent yet.</p>
          ) : (
            <div className="divide-y divide-gray-100">
              {interactions.map((i) => (
                <div key={i.id} className="px-5 py-3.5 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-700">{i.message_body?.slice(0, 80) ?? "—"}…</p>
                    <p className="text-xs text-gray-400 mt-0.5">{formatDateTime(i.sent_at)}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-md font-medium capitalize ${STATUS_COLORS[i.status] ?? "bg-gray-100 text-gray-500"}`}>
                    {i.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Feedback */}
      <section>
        <h2 className="text-sm font-semibold text-gray-900 mb-3">Feedback</h2>
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          {!feedback?.length ? (
            <p className="text-sm text-gray-500 p-5">No feedback submitted yet.</p>
          ) : (
            <div className="divide-y divide-gray-100">
              {feedback.map((f, idx) => (
                <div key={idx} className="px-5 py-3.5">
                  <div className="flex items-center gap-3 mb-1.5">
                    {f.rating && <p className="text-sm font-semibold text-gray-900">{"★".repeat(f.rating)}{"☆".repeat(5 - f.rating)}</p>}
                    {f.sentiment && (
                      <span className={`text-xs px-2 py-0.5 rounded-md font-medium capitalize ${SENTIMENT_COLORS[f.sentiment] ?? ""}`}>
                        {f.sentiment}
                      </span>
                    )}
                    <p className="text-xs text-gray-400 ml-auto">{formatDate(f.submitted_at)}</p>
                  </div>
                  {f.response_text && <p className="text-sm text-gray-600">{f.response_text}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
