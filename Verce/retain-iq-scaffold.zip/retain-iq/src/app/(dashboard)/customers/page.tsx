import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { formatDate } from "@/lib/utils/format";

export const metadata: Metadata = { title: "Customers" };

export default async function CustomersPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: business } = await supabase
    .from("businesses").select("id").eq("owner_id", user.id).single();
  if (!business) redirect("/login");

  const { data: customers } = await supabase
    .from("customers")
    .select("id, name, phone, created_at")
    .eq("business_id", business.id)
    .order("created_at", { ascending: false });

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Customers</h1>
          <p className="text-sm text-gray-500 mt-1">{customers?.length ?? 0} total</p>
        </div>
        <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
          Add customer
        </button>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        {!customers?.length ? (
          <div className="py-16 text-center">
            <p className="text-sm text-gray-500">No customers yet.</p>
            <p className="text-xs text-gray-400 mt-1">Add your first customer to get started.</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Name</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Phone</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Added</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {customers.map((c) => (
                <tr key={c.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-5 py-3.5 text-sm font-medium text-gray-900">{c.name}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-600 font-mono">{c.phone}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-500">{formatDate(c.created_at)}</td>
                  <td className="px-5 py-3.5 text-right">
                    <a href={`/customers/${c.id}`} className="text-xs text-green-600 hover:text-green-700 font-medium">
                      View →
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
