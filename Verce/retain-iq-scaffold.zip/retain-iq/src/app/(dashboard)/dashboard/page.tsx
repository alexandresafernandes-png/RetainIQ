import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "Overview" };

export default async function DashboardPage() {
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: business } = await supabase
    .from("businesses")
    .select("id, name")
    .eq("owner_id", user.id)
    .single();

  if (!business) redirect("/login");

  const bid = business.id;

  const [
    { count: totalCustomers },
    { count: totalInteractions },
    { count: replied },
    { data: feedbackData },
  ] = await Promise.all([
    supabase.from("customers").select("*", { count: "exact", head: true }).eq("business_id", bid),
    supabase.from("interactions").select("*", { count: "exact", head: true }).eq("business_id", bid),
    supabase.from("interactions").select("*", { count: "exact", head: true }).eq("business_id", bid).eq("status", "replied"),
    supabase.from("feedback_sessions").select("rating").eq("business_id", bid).eq("status", "completed"),
  ]);

  const replyRate = totalInteractions ? Math.round(((replied ?? 0) / totalInteractions) * 100) : 0;
  const avgRating = feedbackData?.length
    ? (feedbackData.reduce((s, r) => s + (r.rating ?? 0), 0) / feedbackData.length).toFixed(1)
    : "—";

  const stats = [
    { label: "Total customers", value: totalCustomers ?? 0, sub: "All time" },
    { label: "Messages sent", value: totalInteractions ?? 0, sub: "All time" },
    { label: "Reply rate", value: `${replyRate}%`, sub: "Of sent messages" },
    { label: "Avg. rating", value: avgRating, sub: "Out of 5" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-xl font-semibold text-gray-900">Overview</h1>
        <p className="text-sm text-gray-500 mt-1">{business.name}</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <div key={s.label} className="bg-white border border-gray-200 rounded-xl p-5">
            <p className="text-xs text-gray-500 font-medium">{s.label}</p>
            <p className="text-2xl font-bold text-gray-900 mt-2">{s.value}</p>
            <p className="text-xs text-gray-400 mt-1">{s.sub}</p>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h2 className="text-sm font-semibold text-gray-900 mb-4">Quick actions</h2>
        <div className="flex flex-wrap gap-3">
          <a href="/customers" className="text-sm border border-gray-200 text-gray-700 hover:bg-gray-50 px-4 py-2 rounded-lg transition-colors">
            Add customer
          </a>
          <a href="/messages/templates" className="text-sm border border-gray-200 text-gray-700 hover:bg-gray-50 px-4 py-2 rounded-lg transition-colors">
            Manage templates
          </a>
          <a href="/feedback" className="text-sm border border-gray-200 text-gray-700 hover:bg-gray-50 px-4 py-2 rounded-lg transition-colors">
            View feedback
          </a>
        </div>
      </div>
    </div>
  );
}
