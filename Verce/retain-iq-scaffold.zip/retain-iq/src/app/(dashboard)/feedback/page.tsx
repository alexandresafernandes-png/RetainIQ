import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { formatDate } from "@/lib/utils/format";

export const metadata: Metadata = { title: "Feedback" };

const SENTIMENT_STYLES: Record<string, string> = {
  positive: "bg-green-50 text-green-700",
  neutral: "bg-gray-100 text-gray-600",
  negative: "bg-red-50 text-red-600",
};

export default async function FeedbackPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: business } = await supabase
    .from("businesses").select("id").eq("owner_id", user.id).single();
  if (!business) redirect("/login");

  const { data: sessions } = await supabase
    .from("feedback_sessions")
    .select("id, rating, sentiment, response_text, submitted_at, status, customers(name)")
    .eq("business_id", business.id)
    .eq("status", "completed")
    .order("submitted_at", { ascending: false });

  const avgRating = sessions?.length
    ? (sessions.reduce((s, r) => s + (r.rating ?? 0), 0) / sessions.length).toFixed(1)
    : null;

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-xl font-semibold text-gray-900">Feedback</h1>
        <p className="text-sm text-gray-500 mt-1">
          {sessions?.length ?? 0} responses
          {avgRating ? ` · ${avgRating}/5 avg rating` : ""}
        </p>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        {!sessions?.length ? (
          <div className="py-16 text-center">
            <p className="text-sm text-gray-500">No feedback yet.</p>
            <p className="text-xs text-gray-400 mt-1">Feedback appears here once customers respond.</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Customer</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Rating</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Sentiment</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Response</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {sessions.map((s) => {
                const customer = Array.isArray(s.customers) ? s.customers[0] : s.customers;
                return (
                  <tr key={s.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-5 py-3.5 text-sm font-medium text-gray-900">{customer?.name ?? "—"}</td>
                    <td className="px-5 py-3.5 text-sm text-gray-700">{s.rating ? `${s.rating}/5` : "—"}</td>
                    <td className="px-5 py-3.5">
                      {s.sentiment ? (
                        <span className={`text-xs px-2 py-1 rounded-md font-medium capitalize ${SENTIMENT_STYLES[s.sentiment] ?? ""}`}>
                          {s.sentiment}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-500 max-w-xs truncate">{s.response_text ?? "—"}</td>
                    <td className="px-5 py-3.5 text-sm text-gray-500">{formatDate(s.submitted_at)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
