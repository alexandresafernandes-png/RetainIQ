import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { formatDateTime } from "@/lib/utils/format";
import Link from "next/link";

export const metadata: Metadata = { title: "Messages" };

const STATUS_STYLES: Record<string, string> = {
  sent: "bg-blue-50 text-blue-600",
  delivered: "bg-blue-50 text-blue-700",
  replied: "bg-green-50 text-green-700",
  pending: "bg-gray-100 text-gray-500",
  failed: "bg-red-50 text-red-600",
};

export default async function MessagesPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: business } = await supabase
    .from("businesses").select("id").eq("owner_id", user.id).single();
  if (!business) redirect("/login");

  const { data: interactions } = await supabase
    .from("interactions")
    .select("id, status, sent_at, message_body, customers(name, phone)")
    .eq("business_id", business.id)
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Messages</h1>
          <p className="text-sm text-gray-500 mt-1">All outbound messages</p>
        </div>
        <Link href="/messages/templates" className="border border-gray-200 text-gray-700 hover:bg-gray-50 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
          Manage templates
        </Link>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        {!interactions?.length ? (
          <div className="py-16 text-center">
            <p className="text-sm text-gray-500">No messages sent yet.</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Customer</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Message</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Sent</th>
                <th className="text-left text-xs font-medium text-gray-500 px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {interactions.map((i) => {
                const customer = Array.isArray(i.customers) ? i.customers[0] : i.customers;
                return (
                  <tr key={i.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-5 py-3.5 text-sm font-medium text-gray-900">{customer?.name ?? "—"}</td>
                    <td className="px-5 py-3.5 text-sm text-gray-500 max-w-xs truncate">{i.message_body ?? "—"}</td>
                    <td className="px-5 py-3.5 text-sm text-gray-500">{formatDateTime(i.sent_at)}</td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs px-2 py-1 rounded-md font-medium capitalize ${STATUS_STYLES[i.status] ?? "bg-gray-100 text-gray-500"}`}>
                        {i.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
