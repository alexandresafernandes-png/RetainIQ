import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { formatDate } from "@/lib/utils/format";

export const metadata: Metadata = { title: "Templates" };

export default async function TemplatesPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: business } = await supabase
    .from("businesses").select("id").eq("owner_id", user.id).single();
  if (!business) redirect("/login");

  const { data: templates } = await supabase
    .from("templates")
    .select("*")
    .eq("business_id", business.id)
    .order("created_at", { ascending: false });

  return (
    <div className="p-8 max-w-3xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Templates</h1>
          <p className="text-sm text-gray-500 mt-1">Message templates sent to customers</p>
        </div>
        <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
          New template
        </button>
      </div>

      <div className="space-y-4">
        {!templates?.length ? (
          <div className="bg-white border border-gray-200 rounded-xl py-16 text-center">
            <p className="text-sm text-gray-500">No templates yet.</p>
            <p className="text-xs text-gray-400 mt-1">Create your first follow-up template.</p>
          </div>
        ) : (
          templates.map((t) => (
            <div key={t.id} className="bg-white border border-gray-200 rounded-xl p-5">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-gray-900">{t.name}</h3>
                  {t.is_default && (
                    <span className="text-xs bg-green-50 text-green-600 px-2 py-0.5 rounded-md font-medium">Default</span>
                  )}
                </div>
                <p className="text-xs text-gray-400">{formatDate(t.created_at)}</p>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed bg-gray-50 rounded-lg p-3 font-mono">
                {t.body}
              </p>
              <div className="flex gap-3 mt-3">
                <button className="text-xs text-gray-600 hover:text-gray-900 font-medium">Edit</button>
                <button className="text-xs text-red-500 hover:text-red-600 font-medium">Delete</button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-xl">
        <p className="text-xs font-medium text-blue-700 mb-1">Available variables</p>
        <p className="text-xs text-blue-600 font-mono">{"{{customer_name}}  {{business_name}}  {{service_date}}"}</p>
      </div>
    </div>
  );
}
