import type { Metadata } from "next";

export const metadata: Metadata = { title: "Contact" };

export default function ContactPage() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-20">
      <div className="mb-10">
        <h1 className="text-3xl font-semibold text-gray-900 mb-3">Book a demo</h1>
        <p className="text-gray-500 text-sm leading-relaxed">
          We'll walk you through the product and help you decide if RetainIQ is the right fit.
        </p>
      </div>

      <form className="space-y-5">
        <div className="grid sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Your name</label>
            <input type="text" className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent" placeholder="Ana Silva" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Business name</label>
            <input type="text" className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent" placeholder="Silva Salon" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Email address</label>
          <input type="email" className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent" placeholder="ana@silvasalon.com" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Business type</label>
          <select className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent">
            <option value="">Select a category</option>
            <option>Hair Salon</option>
            <option>Cleaning Service</option>
            <option>Dental Clinic</option>
            <option>Beauty Studio</option>
            <option>Other</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">Message</label>
          <textarea rows={4} className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none" placeholder="Tell us a bit about your business..." />
        </div>
        <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg text-sm font-medium transition-colors">
          Send message
        </button>
      </form>
    </div>
  );
}
