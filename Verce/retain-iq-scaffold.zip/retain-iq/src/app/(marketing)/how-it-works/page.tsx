import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "How It Works" };

export default function HowItWorksPage() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-20">
      <div className="text-center mb-16">
        <h1 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">How RetainIQ works</h1>
        <p className="text-gray-500 max-w-xl mx-auto text-sm leading-relaxed">
          A simple, automated loop that runs in the background while you focus on running your business.
        </p>
      </div>

      <div className="space-y-6">
        {[
          {
            step: "1",
            title: "You add a customer after their visit",
            desc: "Open your dashboard, add the customer name and phone number. You can also import from CSV or connect your booking system.",
          },
          {
            step: "2",
            title: "RetainIQ waits, then sends a WhatsApp message",
            desc: "After 24 hours (or however long you set), a personalised WhatsApp message is sent asking how the service went. No spam. Just one message.",
          },
          {
            step: "3",
            title: "Customer submits feedback via a simple link",
            desc: "The message includes a link to a clean feedback form. They rate the experience and leave a comment. Takes 30 seconds.",
          },
          {
            step: "4",
            title: "You see the results in your dashboard",
            desc: "Replies, sentiment scores, and patterns all show up in one place. You know what customers love — and what needs work.",
          },
        ].map((item) => (
          <div key={item.step} className="flex gap-6 p-6 bg-white border border-gray-200 rounded-xl">
            <div className="w-8 h-8 bg-green-50 text-green-600 rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0">
              {item.step}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-1.5">{item.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 text-center">
        <Link href="/register" className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium text-sm transition-colors">
          Get started free
        </Link>
      </div>
    </div>
  );
}
