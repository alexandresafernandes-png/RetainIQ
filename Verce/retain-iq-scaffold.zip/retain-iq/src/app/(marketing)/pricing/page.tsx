import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Pricing" };

const PLANS = [
  {
    name: "Starter",
    price: "€29",
    period: "/month",
    desc: "For small businesses just getting started.",
    features: ["Up to 100 customers", "WhatsApp follow-ups", "Feedback collection", "Basic dashboard"],
    cta: "Start free trial",
    highlighted: false,
  },
  {
    name: "Growth",
    price: "€79",
    period: "/month",
    desc: "For growing businesses with more customers.",
    features: ["Up to 500 customers", "Everything in Starter", "Sentiment analysis", "Custom templates", "Priority support"],
    cta: "Start free trial",
    highlighted: true,
  },
  {
    name: "Pro",
    price: "€149",
    period: "/month",
    desc: "For multi-location or high-volume businesses.",
    features: ["Unlimited customers", "Everything in Growth", "Multiple locations", "API access", "Dedicated onboarding"],
    cta: "Book a demo",
    highlighted: false,
  },
];

export default function PricingPage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-20">
      <div className="text-center mb-14">
        <h1 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">Simple, transparent pricing</h1>
        <p className="text-gray-500 text-sm">14-day free trial on all plans. No credit card required.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {PLANS.map((plan) => (
          <div key={plan.name} className={`rounded-xl border p-6 flex flex-col ${plan.highlighted ? "border-green-500 bg-green-50 shadow-sm" : "border-gray-200 bg-white"}`}>
            {plan.highlighted && (
              <span className="text-xs font-medium text-green-700 bg-green-100 px-2.5 py-1 rounded-full self-start mb-3">Most popular</span>
            )}
            <h2 className="text-lg font-semibold text-gray-900">{plan.name}</h2>
            <p className="text-sm text-gray-500 mt-1 mb-4">{plan.desc}</p>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-3xl font-bold text-gray-900">{plan.price}</span>
              <span className="text-sm text-gray-500">{plan.period}</span>
            </div>
            <ul className="space-y-2.5 flex-1 mb-6">
              {plan.features.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-gray-700">
                  <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                  {f}
                </li>
              ))}
            </ul>
            <Link href={plan.cta === "Book a demo" ? "/contact" : "/register"}
              className={`text-sm font-medium px-4 py-2.5 rounded-lg text-center transition-colors ${plan.highlighted ? "bg-green-600 hover:bg-green-700 text-white" : "border border-gray-200 text-gray-700 hover:bg-gray-50"}`}>
              {plan.cta}
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
