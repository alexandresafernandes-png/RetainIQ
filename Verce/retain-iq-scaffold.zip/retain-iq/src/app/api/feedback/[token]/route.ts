import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { scoreSentiment } from "@/lib/utils/sentiment";

export async function POST(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const body = await req.json();
  const { rating, response_text } = body;

  if (!rating || rating < 1 || rating > 5) {
    return NextResponse.json({ error: "Invalid rating" }, { status: 400 });
  }

  const supabase = await createClient();

  const { data: session } = await supabase
    .from("feedback_sessions")
    .select("id, status, expires_at")
    .eq("token", token)
    .single();

  if (!session || session.status !== "pending") {
    return NextResponse.json({ error: "Invalid or expired token" }, { status: 404 });
  }

  const sentiment = response_text ? scoreSentiment(response_text) : "neutral";

  const { error } = await supabase
    .from("feedback_sessions")
    .update({
      rating,
      response_text: response_text || null,
      sentiment,
      status: "completed",
      submitted_at: new Date().toISOString(),
    })
    .eq("token", token);

  if (error) {
    return NextResponse.json({ error: "Failed to save" }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
