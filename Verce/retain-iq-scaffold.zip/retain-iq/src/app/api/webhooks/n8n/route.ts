import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const SECRET = process.env.N8N_WEBHOOK_SECRET;

export async function POST(req: NextRequest) {
  // Validate shared secret
  const incomingSecret = req.headers.get("x-n8n-secret");
  if (!SECRET || incomingSecret !== SECRET) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const { event, ...payload } = body;

  const supabase = await createClient();

  switch (event) {
    case "interaction_updated": {
      const { interaction_id, status, delivered_at, replied_at } = payload;
      await supabase
        .from("interactions")
        .update({ status, delivered_at, replied_at })
        .eq("id", interaction_id);
      break;
    }

    default:
      return NextResponse.json({ error: "Unknown event" }, { status: 400 });
  }

  return NextResponse.json({ ok: true });
}
