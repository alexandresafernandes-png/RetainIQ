import { createClient } from "@/lib/supabase/server";
import { notFound } from "next/navigation";
import FeedbackForm from "./FeedbackForm";

export default async function FeedbackPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;

  const supabase = await createClient();
  const { data: session } = await supabase
    .from("feedback_sessions")
    .select("id, status, expires_at, customers(name), businesses(name)")
    .eq("token", token)
    .single();

  if (!session) notFound();

  if (session.status === "completed") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="max-w-sm w-full text-center bg-white border border-gray-200 rounded-xl p-10">
          <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-lg font-semibold text-gray-900 mb-2">Already submitted</h1>
          <p className="text-sm text-gray-500">Your feedback has been received. Thank you!</p>
        </div>
      </div>
    );
  }

  if (session.status === "expired" || (session.expires_at && new Date(session.expires_at) < new Date())) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="max-w-sm w-full text-center bg-white border border-gray-200 rounded-xl p-10">
          <h1 className="text-lg font-semibold text-gray-900 mb-2">Link expired</h1>
          <p className="text-sm text-gray-500">This feedback link is no longer active.</p>
        </div>
      </div>
    );
  }

  const customer = Array.isArray(session.customers) ? session.customers[0] : session.customers;
  const business = Array.isArray(session.businesses) ? session.businesses[0] : session.businesses;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-sm w-full">
        <div className="text-center mb-8">
          <p className="text-xs text-gray-500 uppercase tracking-wider font-medium mb-1">{business?.name}</p>
          <h1 className="text-2xl font-semibold text-gray-900">How did we do?</h1>
          {customer?.name && <p className="text-sm text-gray-500 mt-1">Hi {customer.name}, we'd love your feedback.</p>}
        </div>
        <FeedbackForm token={token} />
      </div>
    </div>
  );
}
