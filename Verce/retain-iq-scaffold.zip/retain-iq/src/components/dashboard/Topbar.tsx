import { createClient } from "@/lib/supabase/server";
import SignOutButton from "./SignOutButton";

interface TopbarProps {
  businessName: string;
}

export default async function Topbar({ businessName }: TopbarProps) {
  return (
    <header className="h-[var(--topbar-height)] bg-white border-b border-neutral-200 flex items-center justify-between px-6 shrink-0">
      <p className="text-sm font-medium text-neutral-700">{businessName}</p>
      <div className="flex items-center gap-3">
        <SignOutButton />
      </div>
    </header>
  );
}
