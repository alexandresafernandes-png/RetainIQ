import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-white">
      <div className="max-w-6xl mx-auto px-6 py-12 flex flex-col md:flex-row justify-between gap-8">
        <div>
          <p className="text-lg font-semibold text-gray-900">
            Retain<span className="text-green-600">IQ</span>
          </p>
          <p className="text-sm text-gray-500 mt-1.5 max-w-xs">
            Automated follow-ups and feedback for local service businesses.
          </p>
        </div>
        <div className="flex gap-12">
          <div className="flex flex-col gap-2">
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Product</p>
            <Link href="/how-it-works" className="text-sm text-gray-700 hover:text-gray-900">How it works</Link>
            <Link href="/pricing" className="text-sm text-gray-700 hover:text-gray-900">Pricing</Link>
          </div>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Company</p>
            <Link href="/contact" className="text-sm text-gray-700 hover:text-gray-900">Contact</Link>
            <Link href="/login" className="text-sm text-gray-700 hover:text-gray-900">Log in</Link>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <p className="text-xs text-gray-500">© 2025 RetainIQ. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
