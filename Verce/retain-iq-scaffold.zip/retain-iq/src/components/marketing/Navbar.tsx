"use client";
import Link from "next/link";
import { useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <nav className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="text-lg font-semibold text-gray-900 tracking-tight">
          Retain<span className="text-green-600">IQ</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link href="/how-it-works" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">How it works</Link>
          <Link href="/pricing" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Pricing</Link>
          <Link href="/contact" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">Contact</Link>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Link href="/login" className="text-sm text-gray-600 hover:text-gray-900 px-3 py-2">Log in</Link>
          <Link href="/register" className="text-sm bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
            Get started
          </Link>
        </div>

        <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
          <div className="w-5 h-px bg-gray-700 mb-1.5" />
          <div className="w-5 h-px bg-gray-700 mb-1.5" />
          <div className="w-5 h-px bg-gray-700" />
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-gray-200 bg-white px-6 py-4 flex flex-col gap-4">
          <Link href="/how-it-works" className="text-sm text-gray-700" onClick={() => setOpen(false)}>How it works</Link>
          <Link href="/pricing" className="text-sm text-gray-700" onClick={() => setOpen(false)}>Pricing</Link>
          <Link href="/contact" className="text-sm text-gray-700" onClick={() => setOpen(false)}>Contact</Link>
          <hr className="border-gray-200" />
          <Link href="/login" className="text-sm text-gray-700" onClick={() => setOpen(false)}>Log in</Link>
          <Link href="/register" className="text-sm bg-green-600 text-white px-4 py-2.5 rounded-lg text-center font-medium" onClick={() => setOpen(false)}>
            Get started
          </Link>
        </div>
      )}
    </header>
  );
}
