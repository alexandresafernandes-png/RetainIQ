const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL!;
const N8N_WEBHOOK_SECRET = process.env.N8N_WEBHOOK_SECRET!;

type TriggerFollowUpPayload = {
  event: "trigger_followup";
  business_id: string;
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  template_body: string;
  delay_hours: number;
};

type FeedbackReceivedPayload = {
  event: "feedback_received";
  business_id: string;
  customer_id: string;
  rating: number;
  sentiment: string;
  feedback_token: string;
};

type WebhookPayload = TriggerFollowUpPayload | FeedbackReceivedPayload;

export async function triggerN8nWebhook(payload: WebhookPayload) {
  const res = await fetch(N8N_WEBHOOK_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-N8N-Secret": N8N_WEBHOOK_SECRET,
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    throw new Error(`n8n webhook failed: ${res.status}`);
  }

  return res.json();
}
